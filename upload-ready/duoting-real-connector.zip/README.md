# Duoting Real Connector

This connector packages the real duoting script downloaded from server.
Runtime auth payload is stored as text and reconstructed during execution.
