import hashlib
import json
import os
import shutil
import subprocess
import sys
import base64
from datetime import datetime, timezone
from pathlib import Path


def emit(event):
    print(json.dumps(event, ensure_ascii=False), flush=True)


def iso_now():
    return datetime.now(timezone.utc).isoformat()


def parse_duoting_time(value):
    if not value:
        return iso_now()
    text = str(value).strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S"):
        try:
            parsed = datetime.strptime(text, fmt)
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(timezone.utc).isoformat()
        except ValueError:
            pass
    return iso_now()


def parse_json_env(name, default):
    raw = os.getenv(name, "")
    if not raw:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default


def scan_media_files(media_root: Path):
    exts = {".mp3", ".m4a", ".aac", ".ogg", ".wav", ".flac", ".oga", ".opus"}
    files = []
    for file in media_root.rglob("*"):
        if file.is_file() and file.suffix.lower() in exts:
            files.append(file)
    files.sort()
    return files


def file_checksum(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def content_type(path: Path):
    mapping = {
        ".mp3": "audio/mpeg",
        ".m4a": "audio/mp4",
        ".aac": "audio/aac",
        ".ogg": "audio/ogg",
        ".wav": "audio/wav",
        ".flac": "audio/flac",
        ".oga": "audio/ogg",
        ".opus": "audio/ogg",
    }
    return mapping.get(path.suffix.lower(), "audio/mpeg")


def read_sidecar(file: Path):
    metadata = {}
    meta_path = Path(f"{file}.json")
    if meta_path.exists():
        try:
            metadata = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception:
            metadata = {}

    caption_path = Path(f"{file}.txt")
    caption = ""
    if caption_path.exists():
        try:
            caption = caption_path.read_text(encoding="utf-8").strip()
        except Exception:
            caption = ""

    return metadata, caption


def copy_with_sidecars(source: Path, target: Path):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    for suffix in (".json", ".txt"):
        sidecar = Path(f"{source}{suffix}")
        if sidecar.exists():
            shutil.copy2(sidecar, Path(f"{target}{suffix}"))


def run_duoting_script(cmd, connector_root: Path, env):
    emit({"type": "log", "level": "info", "message": f"starting duoting sync: {' '.join(cmd)}"})
    process = subprocess.Popen(
        cmd,
        cwd=str(connector_root),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    stdout_lines = []

    if process.stdout is not None:
        for line in process.stdout:
            message = line.rstrip()
            if not message:
                continue
            stdout_lines.append(message)
            emit({"type": "log", "level": "info", "message": message[:4000]})

    return_code = process.wait()
    emit({"type": "log", "level": "info", "message": f"duoting sync finished with exit code {return_code}"})
    return return_code, "\n".join(stdout_lines)


if __name__ == "__main__":
    input_json = parse_json_env("CONNECTOR_INPUT_JSON", {})
    output_root = Path(os.getenv("CONNECTOR_OUTPUT_ROOT", "/work/output"))
    media_root = output_root / "media"
    media_root.mkdir(parents=True, exist_ok=True)

    source_name = str(input_json.get("source_name", "duoting-real"))
    program_title = str(input_json.get("program_title", "新闻酸菜馆"))
    program_description = str(input_json.get("program_description", "新闻酸菜馆节目音频。"))
    limit = int(input_json.get("limit", 30) or 30)

    connector_root = Path.cwd()
    script_abs = connector_root / "scripts/duoting_mac_webapp.py"
    runtime_data = connector_root / "runtime_data"

    # Ensure downloaded audio lands under CONNECTOR_OUTPUT_ROOT/media
    work_data = output_root / "duoting-runtime"
    if work_data.exists():
        shutil.rmtree(work_data)
    shutil.copytree(runtime_data, work_data)
    os.makedirs(work_data / "downloads", exist_ok=True)
    os.makedirs(work_data / "sessions", exist_ok=True)

    auth_payload = work_data / "auth/duoting_auth_payload.txt"
    if auth_payload.exists():
        raw = auth_payload.read_text(encoding="utf-8").strip()
        (work_data / "sessions/duoting_user.session").write_bytes(base64.b64decode(raw))

    cmd = [sys.executable, str(script_abs), "sync-once", "--limit", str(max(1, limit))]
    env = os.environ.copy()
    env["DUOTING_DATA_DIR"] = str(work_data)

    return_code, _ = run_duoting_script(cmd, connector_root, env)

    if return_code != 0:
        emit({"type": "log", "level": "error", "message": f"duoting script exit code={return_code}"})
        raise SystemExit(return_code)

    # Duoting downloads to DUOTING_DATA_DIR/downloads/**, copy audio files to media_root first.
    duoting_downloads = work_data / "downloads"
    discovered_files = scan_media_files(duoting_downloads)
    emit({"type": "log", "level": "info", "message": f"duoting downloaded media files: {len(discovered_files)}"})
    for file in discovered_files:
        rel = file.relative_to(duoting_downloads).as_posix()
        target = media_root / rel
        copy_with_sidecars(file, target)

    external_program_id = f"duoting:{source_name}"
    emit(
        {
            "type": "program",
            "external_program_id": external_program_id,
            "title": program_title,
            "description": program_description,
        }
    )

    media_files = scan_media_files(media_root)
    emit({"type": "log", "level": "info", "message": f"emitting podcast events for media files: {len(media_files)}"})
    for file in media_files:
        rel = file.relative_to(media_root).as_posix()
        eid = f"duoting:{source_name}:{hashlib.md5(rel.encode('utf-8')).hexdigest()}"
        metadata, caption = read_sidecar(file)
        episode_title = str(metadata.get("title") or file.stem).strip() or file.stem
        description = caption or str(metadata.get("caption") or "").strip() or "新闻酸菜馆"
        duration = int(metadata.get("duration") or 0)
        published_at = parse_duoting_time(metadata.get("date"))
        emit(
            {
                "type": "episode",
                "external_episode_id": eid,
                "program_external_id": external_program_id,
                "title": episode_title,
                "description": description,
                "published_at": published_at,
                "duration_seconds": duration,
            }
        )
        emit(
            {
                "type": "media_ready",
                "external_episode_id": eid,
                "file": f"media/{rel}",
                "content_type": content_type(file),
                "size": file.stat().st_size,
                "checksum": file_checksum(file),
                "duration_seconds": duration,
            }
        )
