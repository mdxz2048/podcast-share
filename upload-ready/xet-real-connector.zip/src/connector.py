import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


def emit(event):
    print(json.dumps(event, ensure_ascii=False), flush=True)


def iso_now():
    return datetime.now(timezone.utc).isoformat()


def parse_json_env(name, default):
    raw = os.getenv(name, "")
    if not raw:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default


def scan_media_files(media_root: Path):
    exts = {".mp3", ".m4a", ".aac", ".ogg", ".wav", ".flac"}
    files = []
    for file in media_root.rglob("*"):
        if file.is_file() and file.suffix.lower() in exts:
            files.append(file)
    files.sort()
    return files


def file_checksum(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def content_type(path: Path):
    mapping = {
        ".mp3": "audio/mpeg",
        ".m4a": "audio/mp4",
        ".aac": "audio/aac",
        ".ogg": "audio/ogg",
        ".wav": "audio/wav",
        ".flac": "audio/flac",
    }
    return mapping.get(path.suffix.lower(), "audio/mpeg")


if __name__ == "__main__":
    input_json = parse_json_env("CONNECTOR_INPUT_JSON", {})
    output_root = Path(os.getenv("CONNECTOR_OUTPUT_ROOT", "/work/output"))
    media_root = output_root / "media"
    media_root.mkdir(parents=True, exist_ok=True)

    source_name = str(input_json.get("source_name", "xet-real"))
    program_title = str(input_json.get("program_title", "XET 真实导入"))
    qr_confirmed = bool(input_json.get("qr_confirmed", False))
    limit = int(input_json.get("limit", 1) or 1)
    max_scan = int(input_json.get("max_scan", 64) or 64)

    if not qr_confirmed:
        emit(
            {
                "type": "auth_required",
                "kind": "qr_interactive",
                "label": "请在可交互终端完成 xet.py 扫码后，提交 qr_confirmed=true 再运行",
            }
        )
        emit({"type": "log", "level": "info", "message": "waiting for qr confirmation"})
        raise SystemExit(0)

    connector_root = Path.cwd()
    script_abs = connector_root / "scripts/xet.py"
    profile_src = connector_root / "runtime_data/profile"
    profile_dir = output_root / "xet-profile"
    if profile_dir.exists():
        shutil.rmtree(profile_dir)
    shutil.copytree(profile_src, profile_dir)
    auth_blob = profile_dir / "xet_auth_store.txt"
    if auth_blob.exists():
        auth_blob.rename(profile_dir / "cookies.txt")
    csv_path = output_root / "episodes.selected.csv"
    manifest_path = output_root / "episodes.json"

    cmd = [
        sys.executable,
        str(script_abs),
        "latest",
        "--profile-dir",
        str(profile_dir),
        "--download-dir",
        str(media_root),
        "--csv-output",
        str(csv_path),
        "--manifest-output",
        str(manifest_path),
        "--limit",
        str(max(1, limit)),
        "--max-scan",
        str(max(1, max_scan)),
    ]

    result = subprocess.run(cmd, cwd=str(connector_root), env=os.environ.copy(), capture_output=True, text=True)
    if result.stdout.strip():
        emit({"type": "log", "level": "info", "message": result.stdout.strip()[:4000]})
    if result.stderr.strip():
        emit({"type": "log", "level": "warn", "message": result.stderr.strip()[:4000]})

    if result.returncode != 0:
        emit({"type": "log", "level": "error", "message": f"xet.py exit code={result.returncode}"})
        raise SystemExit(result.returncode)

    external_program_id = f"xet:{source_name}"
    emit(
        {
            "type": "program",
            "external_program_id": external_program_id,
            "title": program_title,
            "description": f"Imported by real xet.py source={source_name}",
        }
    )

    for file in scan_media_files(media_root):
        rel = file.relative_to(media_root).as_posix()
        eid = f"xet:{source_name}:{hashlib.md5(rel.encode('utf-8')).hexdigest()}"
        emit(
            {
                "type": "episode",
                "external_episode_id": eid,
                "program_external_id": external_program_id,
                "title": file.stem,
                "description": "Imported from real xet script",
                "published_at": iso_now(),
            }
        )
        emit(
            {
                "type": "media_ready",
                "external_episode_id": eid,
                "file": f"media/{rel}",
                "content_type": content_type(file),
                "size": file.stat().st_size,
                "checksum": file_checksum(file),
            }
        )
