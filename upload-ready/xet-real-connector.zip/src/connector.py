import hashlib
import base64
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path


def emit(event):
    print(json.dumps(event, ensure_ascii=False), flush=True)


def iso_now():
    return datetime.now(timezone.utc).isoformat()


def parse_json_env(name, default):
    raw = os.getenv(name, "")
    if not raw:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default


def scan_media_files(media_root: Path):
    exts = {".mp3", ".m4a", ".aac", ".ogg", ".wav", ".flac"}
    files = []
    for file in media_root.rglob("*"):
        if file.is_file() and file.suffix.lower() in exts:
            files.append(file)
    files.sort()
    return files


def file_checksum(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def content_type(path: Path):
    mapping = {
        ".mp3": "audio/mpeg",
        ".m4a": "audio/mp4",
        ".aac": "audio/aac",
        ".ogg": "audio/ogg",
        ".wav": "audio/wav",
        ".flac": "audio/flac",
    }
    return mapping.get(path.suffix.lower(), "audio/mpeg")


def image_content_type(path: Path):
    if path.suffix.lower() in {".jpg", ".jpeg"}:
        return "image/jpeg"
    if path.suffix.lower() == ".png":
        return "image/png"
    return "application/octet-stream"


def image_data_url(path: Path):
    return f"data:{image_content_type(path)};base64,{base64.b64encode(path.read_bytes()).decode('ascii')}"


def watch_qr_images(profile_dir: Path, stop_event: threading.Event):
    candidates = [
        ("study_login", profile_dir / "login-qr.jpg"),
        ("h5_login", profile_dir / "h5-login-qr.png"),
    ]
    emitted: set[Path] = set()
    while not stop_event.is_set():
        for label, path in candidates:
            if path in emitted or not path.exists() or path.stat().st_size <= 0:
                continue
            try:
                emit(
                    {
                        "type": "qr_image",
                        "level": "info",
                        "message": "Scan this QR code with WeChat.",
                        "label": label,
                        "image_data_url": image_data_url(path),
                    }
                )
                emitted.add(path)
            except Exception as error:
                emit({"type": "log", "level": "warn", "message": f"failed to emit QR image: {error}"})
        stop_event.wait(0.2)


if __name__ == "__main__":
    input_json = parse_json_env("CONNECTOR_INPUT_JSON", {})
    output_root = Path(os.getenv("CONNECTOR_OUTPUT_ROOT", "/work/output"))
    media_root = output_root / "media"
    media_root.mkdir(parents=True, exist_ok=True)

    source_name = str(input_json.get("source_name", "xet-real"))
    program_title = str(input_json.get("program_title", "XET 真实导入"))
    limit = int(input_json.get("limit", 1) or 1)
    max_scan = int(input_json.get("max_scan", 64) or 64)

    connector_root = Path.cwd()
    script_abs = connector_root / "scripts/xet.py"
    profile_src = connector_root / "runtime_data/profile"
    profile_dir = output_root / "xet-profile"
    if profile_dir.exists():
        shutil.rmtree(profile_dir)
    shutil.copytree(profile_src, profile_dir)
    auth_blob = profile_dir / "xet_auth_store.txt"
    if auth_blob.exists():
        auth_blob.rename(profile_dir / "cookies.txt")
    csv_path = output_root / "episodes.selected.csv"
    manifest_path = output_root / "episodes.json"

    cmd = [
        sys.executable,
        str(script_abs),
        "latest",
        "--profile-dir",
        str(profile_dir),
        "--download-dir",
        str(media_root),
        "--csv-output",
        str(csv_path),
        "--manifest-output",
        str(manifest_path),
        "--limit",
        str(max(1, limit)),
        "--max-scan",
        str(max(1, max_scan)),
    ]

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    emit({"type": "log", "level": "info", "message": "starting real xet.py in streaming mode"})
    emit({"type": "log", "level": "info", "message": f"download dir: {media_root}"})
    if cmd[0].endswith("python") or cmd[0].endswith("python3"):
        cmd.insert(1, "-u")

    process = subprocess.Popen(
        cmd,
        cwd=str(connector_root),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )

    qr_stop_event = threading.Event()
    qr_thread = threading.Thread(target=watch_qr_images, args=(profile_dir, qr_stop_event), daemon=True)
    qr_thread.start()

    def stream_pipe(pipe, level):
        if pipe is None:
            return
        for line in iter(pipe.readline, ""):
            stripped = line.rstrip("\n")
            if not stripped:
                continue
            emit({"type": "log", "level": level, "message": stripped[:4000]})

    stdout_thread = threading.Thread(target=stream_pipe, args=(process.stdout, "info"), daemon=True)
    stderr_thread = threading.Thread(target=stream_pipe, args=(process.stderr, "warn"), daemon=True)
    stdout_thread.start()
    stderr_thread.start()
    process.wait()
    qr_stop_event.set()
    qr_thread.join(timeout=1)
    stdout_thread.join(timeout=1)
    stderr_thread.join(timeout=1)

    if process.stdout:
        process.stdout.close()
    if process.stderr:
        process.stderr.close()

    if process.returncode != 0:
        emit({"type": "log", "level": "error", "message": f"xet.py exit code={process.returncode}"})
        raise SystemExit(process.returncode)

    external_program_id = f"xet:{source_name}"
    emit(
        {
            "type": "program",
            "external_program_id": external_program_id,
            "title": program_title,
            "description": f"Imported by real xet.py source={source_name}",
        }
    )

    for file in scan_media_files(media_root):
        rel = file.relative_to(media_root).as_posix()
        eid = f"xet:{source_name}:{hashlib.md5(rel.encode('utf-8')).hexdigest()}"
        emit(
            {
                "type": "episode",
                "external_episode_id": eid,
                "program_external_id": external_program_id,
                "title": file.stem,
                "description": "Imported from real xet script",
                "published_at": iso_now(),
            }
        )
        emit(
            {
                "type": "media_ready",
                "external_episode_id": eid,
                "file": f"media/{rel}",
                "content_type": content_type(file),
                "size": file.stat().st_size,
                "checksum": file_checksum(file),
            }
        )
