# XET Real Connector

This connector packages the real xet.py script downloaded from server.
Profile auth cookies are stored as text and reconstructed during execution.
