import argparse
import csv
import json
import os
import platform
import re
import shutil
import sys
import time
import webbrowser
from dataclasses import dataclass
from datetime import datetime, timezone
from http.cookiejar import MozillaCookieJar
from io import BytesIO
from pathlib import Path
from typing import Iterable
from urllib.parse import quote, urlparse

import cv2
import numpy as np
import qrcode
import requests
from requests.exceptions import JSONDecodeError as RequestsJSONDecodeError
from requests.cookies import create_cookie

try:
    import browser_cookie3
except ImportError:
    browser_cookie3 = None

try:
    from playwright.sync_api import Error as PlaywrightError
    from playwright.sync_api import sync_playwright
except ImportError:
    PlaywrightError = None
    sync_playwright = None

try:
    from pyzbar.pyzbar import decode as pyzbar_decode
except ImportError:
    pyzbar_decode = None

STUDY_ORIGIN = "https://study.xiaoe-tech.com"
LEARN_LOGIN_URL = f"{STUDY_ORIGIN}/t_l/learnLogin#/wx"
LEARN_INDEX_URL = f"{STUDY_ORIGIN}/t_l/learnIndex?type=wx#/muti_index"
DEFAULT_PROFILE_DIR = Path(".xet-profile")
DEFAULT_DOWNLOAD_DIR = Path("audio")
DEFAULT_CSV_OUTPUT = Path("episodes.selected.csv")
DEFAULT_MANIFEST_OUTPUT = DEFAULT_DOWNLOAD_DIR / "episodes.json"
DEFAULT_PAGE_SIZE = 16
DEFAULT_TIMEOUT = 20
DEFAULT_LOGIN_TIMEOUT = 300
REQUIRED_H5_COOKIE_NAMES = {
    "ko_token",
    "colla_login",
    "newuserdays",
    "olduserdays",
    "logintime",
    "shop_version_type",
}
EMBEDDED_BROWSER_DIRNAME = "playwright-h5-profile"


def running_in_wsl() -> bool:
    release = platform.release().lower()
    version = platform.version().lower()
    return "microsoft" in release or "microsoft" in version


def has_graphical_display() -> bool:
    system = platform.system()
    if system in {"Windows", "Darwin"}:
        return True
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def running_over_ssh() -> bool:
    return bool(os.environ.get("SSH_CONNECTION") or os.environ.get("SSH_CLIENT") or os.environ.get("SSH_TTY"))


@dataclass
class Episode:
    resource_id: str
    app_id: str
    title: str
    page_url: str
    pub_date: str = ""
    author: str = ""
    image_url: str = ""
    description: str = ""
    audio_url: str = ""
    file_name: str = ""
    file_size: int = 0
    mime_type: str = "audio/mpeg"


class XetClient:
    def __init__(self, profile_dir: Path, timeout: int = DEFAULT_TIMEOUT):
        self.profile_dir = Path(profile_dir)
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.cookie_path = self.profile_dir / "cookies.txt"
        self.timeout = timeout
        self.synced_apps: set[str] = set()
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": (
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
                ),
                "Accept": "application/json, text/plain, */*",
            }
        )
        self.session.cookies = MozillaCookieJar(str(self.cookie_path))
        if self.cookie_path.exists():
            self.session.cookies.load(ignore_discard=True, ignore_expires=True)

    def save_cookies(self) -> None:
        self.session.cookies.save(ignore_discard=True, ignore_expires=True)

    def post_json(self, url: str, payload: dict | None = None) -> dict:
        response = self.session.post(url, json=payload or {}, timeout=self.timeout)
        response.raise_for_status()
        try:
            return response.json()
        except RequestsJSONDecodeError as exc:
            body = response.text.strip()
            snippet = body[:200] if body else "<empty response body>"
            raise RuntimeError(f"Expected JSON from {url}, got: {snippet}") from exc

    def post_form(self, url: str, payload: dict[str, str]) -> dict:
        response = self.session.post(
            url,
            data=payload,
            headers={"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
            timeout=self.timeout,
        )
        response.raise_for_status()
        try:
            return response.json()
        except RequestsJSONDecodeError as exc:
            body = response.text.strip()
            snippet = body[:200] if body else "<empty response body>"
            raise RuntimeError(f"Expected JSON from {url}, got: {snippet}") from exc

    def check_token(self) -> dict:
        return self.post_json(f"{STUDY_ORIGIN}/xe.learn-pc.user/check_token", {})

    def create_scan_code(self) -> dict:
        return self.post_json(f"{STUDY_ORIGIN}/xe.learn-pc.create_scan_code/1.0.0", {})

    def poll_scan_status(self, code: str) -> dict:
        return self.post_json(f"{STUDY_ORIGIN}/xe.learn-pc.scan_status_get/1.0.0", {"code": code})

    def ensure_logged_in(self, login_timeout: int = DEFAULT_LOGIN_TIMEOUT) -> dict:
        token_state = self.check_token()
        if token_state.get("code") == 0 and token_state.get("data", {}).get("token_info", {}).get("value"):
            return token_state

        created = self.create_scan_code()
        qr_data = created.get("data", {})
        code = qr_data.get("code")
        img_url = qr_data.get("img_url")
        if not code or not img_url:
            raise RuntimeError("Could not obtain a login QR code.")

        qr_image_path = self.profile_dir / "login-qr.jpg"
        render_qr_to_terminal(self.session, img_url, qr_image_path)
        print("Waiting for scan and authorization...")

        deadline = time.time() + login_timeout
        while time.time() < deadline:
            time.sleep(2)
            state = self.poll_scan_status(code)
            payload = state.get("data", {})
            status = payload.get("status")

            if status == 10000:
                verified = self.check_token()
                if verified.get("code") == 0 and verified.get("data", {}).get("token_info", {}).get("value"):
                    self.save_cookies()
                    return verified
            elif status in {10002, 10003, 10006}:
                continue
            elif status == 10004:
                raise RuntimeError("The QR code expired. Run the command again to refresh it.")
            elif status == 10005:
                raise RuntimeError("Authorization failed in WeChat.")
            elif status == 10044:
                raise RuntimeError("QR scan failed. Run the command again.")

        raise RuntimeError("Timed out waiting for QR login.")

    def fetch_episode_page(self, page: int, page_size: int) -> dict:
        payload = {
            "page_size": page_size,
            "page": page,
            "agent_type": 7,
            "resource_type": ["0"],
        }
        return self.post_json(f"{STUDY_ORIGIN}/xe.learn-pc/my_attend_normal_list.get/1.0.1", payload)

    def fetch_all_audio_episodes(self, page_size: int = DEFAULT_PAGE_SIZE) -> list[Episode]:
        episodes: list[Episode] = []
        page = 1
        while True:
            data = self.fetch_episode_page(page, page_size)
            items = data.get("data", {}).get("list", [])
            for item in items:
                if item.get("resource_type") != 2:
                    continue
                h5_url = item.get("h5_url") or ""
                if "/audio/" not in h5_url:
                    continue
                episodes.append(
                    Episode(
                        resource_id=item.get("resource_id") or item.get("resources_id") or "",
                        app_id=item.get("app_id") or extract_app_id(h5_url),
                        title=item.get("title") or "",
                        page_url=normalize_page_url(h5_url),
                        pub_date=(item.get("last_learn_at") or "")[:10],
                        author=item.get("shop_name") or "",
                        image_url=item.get("img_url") or item.get("img_url_compressed") or "",
                    )
                )
            if len(items) < page_size:
                break
            page += 1
        return episodes

    def get_h5_origin(self, app_id: str) -> str:
        return f"https://{app_id}.h5.xiaoeknow.com"

    def get_h5_token(self, app_id: str) -> str:
        payload = self.post_json(f"{self.get_h5_origin(app_id)}/account/check-auth-new", {})
        data = payload.get("data")
        if isinstance(data, dict):
            return str(data.get("token") or "")
        return ""

    def sync_h5_login(self, app_id: str) -> tuple[bool, str]:
        base = self.get_h5_origin(app_id)
        payload = self.post_json(f"{base}/xe.account-platform.go_auth.outer.pass.multi_login.get_url_list", {})
        data = payload.get("data")
        if payload.get("code") != 0 or not isinstance(data, dict):
            return False, str(payload.get("msg") or "unknown error")
        for url in data.get("url_list", []):
            response = self.session.get(url, timeout=self.timeout)
            response.raise_for_status()
        self.synced_apps.add(app_id)
        self.save_cookies()
        return True, ""

    def merge_cookiejar(self, cookiejar: Iterable) -> int:
        count = 0
        for cookie in cookiejar:
            self.session.cookies.set_cookie(cookie)
            count += 1
        if count:
            self.save_cookies()
        return count

    def import_browser_cookies(self, app_id: str) -> bool:
        if browser_cookie3 is None:
            return False

        browser_loaders = [
            getattr(browser_cookie3, name)
            for name in ("edge", "chrome", "brave", "chromium", "firefox", "opera", "vivaldi")
            if hasattr(browser_cookie3, name)
        ]
        domain_candidates = [
            f"{app_id.lower()}.h5.xiaoeknow.com",
            f"{app_id.lower()}.h5.xiaoecloud.com",
            ".xiaoe-tech.com",
        ]

        imported = 0
        for loader in browser_loaders:
            for domain in domain_candidates:
                try:
                    imported += self.merge_cookiejar(loader(domain_name=domain))
                except Exception:
                    continue

        if not imported:
            return False
        token = self.get_h5_token(app_id)
        return bool(token and token != "good_token")

    def import_cookie_pairs(self, app_id: str, cookies: dict[str, str]) -> bool:
        if "ko_token" not in cookies:
            return False

        target_domains = [
            f"{app_id.lower()}.h5.xiaoeknow.com",
            f"{app_id.lower()}.h5.xiaoecloud.com",
        ]
        for domain in target_domains:
            for name, value in cookies.items():
                self.session.cookies.set_cookie(create_cookie(name=name, value=value, domain=domain, path="/"))
        self.save_cookies()
        token = self.get_h5_token(app_id)
        return bool(token and token != "good_token")

    def import_cookie_string(self, app_id: str, cookie_string: str) -> bool:
        cookie_string = cookie_string.strip().strip("\"'")
        if not cookie_string:
            return False

        parsed: dict[str, str] = {}
        for chunk in cookie_string.split(";"):
            part = chunk.strip()
            if not part or "=" not in part:
                continue
            name, value = part.split("=", 1)
            name = name.strip()
            if not name:
                continue
            parsed[name] = value.strip()
        return self.import_cookie_pairs(app_id, parsed)

    def login_with_embedded_browser(self, app_id: str, login_timeout: int = DEFAULT_LOGIN_TIMEOUT) -> bool:
        if sync_playwright is None or not sys.stdin.isatty():
            return False
        if not has_graphical_display():
            print("Built-in browser login needs a graphical session. No DISPLAY / WAYLAND_DISPLAY was detected.")
            return False

        browser_profile_dir = self.profile_dir / EMBEDDED_BROWSER_DIRNAME
        browser_profile_dir.mkdir(parents=True, exist_ok=True)
        login_url = self.get_h5_login_url(app_id)
        print("Opening the built-in browser window for H5 login...")
        print("Complete the login in that window. The script will continue automatically once H5 cookies are ready.")

        try:
            with sync_playwright() as playwright:
                context = playwright.chromium.launch_persistent_context(
                    str(browser_profile_dir),
                    headless=False,
                    args=["--disable-dev-shm-usage"],
                )
                try:
                    page = context.pages[0] if context.pages else context.new_page()
                    page.goto(login_url, wait_until="domcontentloaded", timeout=30000)

                    deadline = time.time() + login_timeout
                    while time.time() < deadline:
                        cookies = context.cookies()
                        relevant = {
                            cookie["name"]: cookie["value"]
                            for cookie in cookies
                            if cookie.get("domain", "").lower()
                            in {
                                f"{app_id.lower()}.h5.xiaoeknow.com",
                                f".{app_id.lower()}.h5.xiaoeknow.com",
                                f"{app_id.lower()}.h5.xiaoecloud.com",
                                f".{app_id.lower()}.h5.xiaoecloud.com",
                            }
                            and cookie.get("name") in REQUIRED_H5_COOKIE_NAMES
                        }
                        if self.import_cookie_pairs(app_id, relevant):
                            print("Imported H5 cookies from the built-in browser window.")
                            return True
                        time.sleep(2)
                finally:
                    context.close()
        except PlaywrightError as exc:
            print(f"Built-in browser login is unavailable: {exc}")
            print("Install browser runtime with: python3 -m playwright install chromium")
        except Exception as exc:
            print(f"Built-in browser login failed: {exc}")

        return False

    def get_h5_login_url(self, app_id: str) -> str:
        base = self.get_h5_origin(app_id)
        redirect_url = quote(f"{base}/p/decorate/personal_center", safe="")
        return f"{base}/p/t/free/v1/basic-platform/h5_basic/login/auth?redirect_url={redirect_url}"

    def create_h5_scan_code(self, app_id: str, login_key: int | str = 0) -> dict:
        base = self.get_h5_origin(app_id)
        payload = {
            "app_id": app_id,
            "bizData": {
                "login_key": login_key,
            },
        }
        return self.post_json(f"{base}/xe.account-platform.account.auth.get_qr_code", payload)

    def poll_h5_scan_status(self, app_id: str, code: str, login_key: int | str = 0) -> dict:
        base = self.get_h5_origin(app_id)
        payload = {
            "app_id": app_id,
            "bizData": {
                "code": code,
                "login_key": login_key,
            },
        }
        return self.post_json(f"{base}/xe.account-platform.account.auth.authorize_status", payload)

    def login_h5_with_qr(self, app_id: str, login_timeout: int = DEFAULT_LOGIN_TIMEOUT) -> bool:
        if not sys.stdin.isatty():
            return False

        created = self.create_h5_scan_code(app_id)
        qr_data = created.get("data", {})
        code = qr_data.get("code")
        qr_code_url = qr_data.get("qr_code_url")
        if created.get("code") != 0 or not code or not qr_code_url:
            return False

        qr_image_path = self.profile_dir / "h5-login-qr.png"
        print("Study login is ready, but this app still needs H5-side auth.")
        print("Scan the H5 login QR code below with WeChat and confirm login.")
        render_qr_payload_to_terminal(qr_code_url, qr_image_path)

        deadline = time.time() + login_timeout
        while time.time() < deadline:
            time.sleep(2)
            state = self.poll_h5_scan_status(app_id, code)
            status_code = state.get("code")
            if status_code == 0:
                token = self.get_h5_token(app_id)
                if token and token != "good_token":
                    self.save_cookies()
                    return True
                ok, _ = self.sync_h5_login(app_id)
                if ok:
                    return True
                return False
            if status_code == 10001:
                print("The H5 login QR code expired.")
                return False
            if status_code == 10002:
                continue
            if status_code in {10003, 10004, 10005}:
                print(f"H5 QR login failed: {state.get('msg') or status_code}")
                return False

        print("Timed out waiting for H5 QR login.")
        return False

    def import_env_cookie_string(self, app_id: str) -> bool:
        env_cookie = os.environ.get("XET_H5_COOKIE", "").strip()
        if env_cookie and self.import_cookie_string(app_id, env_cookie):
            print("Imported H5 cookies from XET_H5_COOKIE.")
            return True
        return False

    def open_h5_login_page(self, app_id: str) -> None:
        login_url = self.get_h5_login_url(app_id)
        print("Opening the H5 login page in your default browser...")
        print(f"If the browser does not open, visit this URL manually:\n{login_url}")
        webbrowser.open(login_url)

    def bootstrap_h5_login(self, app_id: str) -> bool:
        if self.login_h5_with_qr(app_id):
            print("Established H5 login from the terminal QR flow.")
            return True

        if self.login_with_embedded_browser(app_id):
            return True

        if self.import_browser_cookies(app_id):
            print("Imported H5 cookies from a local browser session.")
            return True

        if self.import_env_cookie_string(app_id):
            return True

        if not sys.stdin.isatty():
            return False
        if not has_graphical_display():
            print("No graphical session is available for H5 login.")
            if running_over_ssh():
                print("SSH sessions cannot pop up the built-in browser on the server.")
            print("Bootstrap once on a machine with a GUI, then copy .xet-profile to this machine, or provide XET_H5_COOKIE explicitly.")
            return False

        self.open_h5_login_page(app_id)
        input("Complete the browser login if needed, then press Enter here to continue...")
        if self.login_with_embedded_browser(app_id):
            return True
        if self.import_browser_cookies(app_id):
            print("Imported H5 cookies after browser login.")
            return True
        if self.import_env_cookie_string(app_id):
            return True
        print("Could not establish H5 login with the built-in browser.")
        if running_in_wsl():
            print("WSL QR login only authenticates study.xiaoe-tech.com. Audio download still needs a separate H5 login state.")
            print("On a headless server, bootstrap once in a graphical environment and copy .xet-profile, or provide XET_H5_COOKIE from an already logged-in H5 page.")
        else:
            print("If this machine has no GUI session, bootstrap once elsewhere and copy .xet-profile, or provide XET_H5_COOKIE explicitly.")
        return False

    def ensure_h5_login(self, app_id: str) -> None:
        if app_id in self.synced_apps:
            return
        ok, message = self.sync_h5_login(app_id)
        if ok:
            return

        token = self.get_h5_token(app_id)
        if token == "good_token" or not token:
            if self.bootstrap_h5_login(app_id):
                ok, message = self.sync_h5_login(app_id)
                if ok:
                    return

        raise RuntimeError(f"H5 auth sync failed for {app_id}: {message}")

    def fetch_audio_info(self, episode: Episode) -> Episode:
        self.ensure_h5_login(episode.app_id)
        base = f"https://{episode.app_id}.h5.xiaoeknow.com"
        payload = {
            "bizData[resource_id]": episode.resource_id,
            "bizData[opr_sys]": "Linux x86_64",
        }
        data = self.post_form(f"{base}/xe.course.business.audio.info.get/2.0.0", payload)
        info = data.get("data", {}).get("audio_info", {})
        episode.title = info.get("title") or episode.title
        episode.audio_url = info.get("audio_url") or ""
        episode.pub_date = (info.get("start_at") or episode.pub_date or "")[:10]
        return episode

    def download_episode(self, episode: Episode, download_dir: Path) -> Episode:
        if not episode.audio_url:
            raise RuntimeError(f"Missing audio URL for {episode.title}")

        download_dir.mkdir(parents=True, exist_ok=True)
        suffix = Path(urlparse(episode.audio_url).path).suffix or ".mp3"
        file_name = safe_file_name(episode.title, suffix)
        output_path = download_dir / file_name

        with self.session.get(episode.audio_url, stream=True, timeout=self.timeout) as response:
            response.raise_for_status()
            with output_path.open("wb") as handle:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        handle.write(chunk)
            episode.mime_type = response.headers.get("content-type", "audio/mpeg")

        episode.file_name = file_name
        episode.file_size = output_path.stat().st_size
        return episode


def extract_app_id(h5_url: str) -> str:
    try:
        return urlparse(h5_url).hostname.split(".")[0]
    except Exception:
        return ""


def normalize_page_url(h5_url: str) -> str:
    return h5_url.replace("/v1/course/audio/", "/p/course/audio/")


def safe_file_name(title: str, suffix: str) -> str:
    cleaned = re.sub(r'[\\/:*?"<>|]', '_', title).strip()
    cleaned = re.sub(r"\s+", " ", cleaned)
    return f"{cleaned or 'episode'}{suffix}"


def render_qr_to_terminal(session: requests.Session, img_url: str, image_path: Path) -> None:
    response = session.get(img_url, timeout=DEFAULT_TIMEOUT)
    response.raise_for_status()
    image_bytes = response.content
    image_path.write_bytes(image_bytes)

    try:
        image_array = np.frombuffer(image_bytes, dtype=np.uint8)
        decoded = cv2.imdecode(image_array, cv2.IMREAD_GRAYSCALE)
        if decoded is None:
            raise RuntimeError("Could not decode the QR image bytes.")

        qr_text = decode_qr_payload(decoded)
        if qr_text:
            qr = qrcode.QRCode(border=1)
            qr.add_data(qr_text)
            qr.make(fit=True)
            matrix = np.array(qr.get_matrix(), dtype=np.uint8)
            matrix = np.where(matrix == 1, 0, 255).astype(np.uint8)
            render_binary_qr_to_terminal(matrix)
        else:
            render_binary_qr_to_terminal(decoded)
        print("Scan the QR code above with WeChat.")
    except Exception as error:
        print("Could not render the QR directly in this terminal.")
        print(f"Open this image if needed: {image_path}")
        print(f"QR image URL: {img_url}")
        print(f"QR render fallback reason: {error}")


def render_qr_payload_to_terminal(payload: str, image_path: Path) -> None:
    qr = qrcode.QRCode(border=1, error_correction=qrcode.constants.ERROR_CORRECT_M)
    qr.add_data(payload)
    qr.make(fit=True)

    matrix = np.array(qr.get_matrix(), dtype=np.uint8)
    binary = np.where(matrix == 1, 0, 255).astype(np.uint8)
    preview = cv2.resize(binary, None, fx=12, fy=12, interpolation=cv2.INTER_NEAREST)
    cv2.imwrite(str(image_path), preview)
    render_binary_qr_to_terminal(binary)
    print("Scan the QR code above with WeChat.")


def decode_qr_payload(image: np.ndarray) -> str:
    if pyzbar_decode is not None:
        try:
            result = pyzbar_decode(image)
            if result:
                return result[0].data.decode("utf-8")
        except Exception:
            pass

    detector = cv2.QRCodeDetector()
    qr_text, _, _ = detector.detectAndDecode(image)
    return qr_text or ""


def render_binary_qr_to_terminal(image: np.ndarray) -> None:
    if len(image.shape) == 3:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    _, binary = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    dark_pixels = cv2.findNonZero(255 - binary)
    if dark_pixels is not None:
        x, y, width, height = cv2.boundingRect(dark_pixels)
        binary = binary[y : y + height, x : x + width]

    border = max(4, round(min(binary.shape[0], binary.shape[1]) * 0.08))
    binary = cv2.copyMakeBorder(binary, border, border, border, border, cv2.BORDER_CONSTANT, value=255)

    terminal_width = shutil.get_terminal_size((100, 30)).columns
    target_width = max(48, min(terminal_width - 4, 120))
    target_pixel_height = max(48, round(binary.shape[0] * target_width / binary.shape[1]))
    if target_pixel_height % 2 == 1:
        target_pixel_height += 1

    resized = cv2.resize(binary, (target_width, target_pixel_height), interpolation=cv2.INTER_NEAREST)
    print("")
    margin = "  "
    for row_index in range(0, resized.shape[0], 2):
        upper = resized[row_index]
        lower = resized[row_index + 1]
        chars = []
        for upper_pixel, lower_pixel in zip(upper, lower):
            upper_dark = upper_pixel <= 127
            lower_dark = lower_pixel <= 127
            if upper_dark and lower_dark:
                chars.append("█")
            elif upper_dark:
                chars.append("▀")
            elif lower_dark:
                chars.append("▄")
            else:
                chars.append(" ")
        print(margin + "".join(chars))
    print("")


def format_episode_line(episode: Episode, index: int) -> str:
    date_text = episode.pub_date or "----------"
    author_text = f" | {episode.author}" if episode.author else ""
    return f"{index + 1:>3}. {date_text}{author_text} | {episode.title}"


def parse_selection(text: str, count: int) -> list[int]:
    value = text.strip().lower()
    value = value.replace("，", ",").replace("、", ",")
    if not value:
        return []
    if value == "all":
        return list(range(count))

    selected: set[int] = set()
    for part in value.split(","):
        item = part.strip()
        if not item:
            continue
        match = re.match(r"^(\d+)-(\d+)$", item)
        if match:
            start = int(match.group(1))
            end = int(match.group(2))
            if start < 1 or end < 1 or start > end or end > count:
                raise ValueError(f"Invalid range: {item}")
            for current in range(start, end + 1):
                selected.add(current - 1)
            continue
        if not item.isdigit():
            raise ValueError(f"Invalid selection: {item}")
        number = int(item)
        if number < 1 or number > count:
            raise ValueError(f"Invalid selection: {item}")
        selected.add(number - 1)
    return sorted(selected)


def prompt_for_episodes(episodes: list[Episode]) -> list[Episode]:
    print("Available audio episodes:")
    for index, episode in enumerate(episodes):
        print(format_episode_line(episode, index))
    print("")
    print("Choose episodes by number. Examples: 1,3,5-8 or all")

    while True:
        answer = input("Selection: ")
        try:
            indexes = parse_selection(answer, len(episodes))
            if not indexes:
                print("Please choose at least one episode.")
                continue
            return [episodes[index] for index in indexes]
        except ValueError as error:
            print(error)


def write_csv(episodes: Iterable[Episode], csv_path: Path) -> None:
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["id", "title", "pubDate", "pageUrl", "author", "description", "imageUrl", "url"],
        )
        writer.writeheader()
        for episode in episodes:
            writer.writerow(
                {
                    "id": episode.resource_id,
                    "title": episode.title,
                    "pubDate": episode.pub_date,
                    "pageUrl": episode.page_url,
                    "author": episode.author,
                    "description": episode.description,
                    "imageUrl": episode.image_url,
                    "url": episode.audio_url,
                }
            )


def write_manifest(episodes: Iterable[Episode], manifest_path: Path) -> None:
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    payload = [
        {
            "id": episode.resource_id,
            "title": episode.title,
            "pubDate": episode.pub_date,
            "updated": datetime.now(timezone.utc).isoformat(),
            "pageUrl": episode.page_url,
            "description": episode.description,
            "author": episode.author,
            "imageUrl": episode.image_url,
            "originalUrl": episode.audio_url,
            "fileName": episode.file_name,
            "fileSize": episode.file_size,
            "mimeType": episode.mime_type,
        }
        for episode in episodes
    ]
    manifest_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def load_manifest_episodes(manifest_path: Path) -> list[dict]:
    if not manifest_path.exists():
        return []
    try:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    return payload if isinstance(payload, list) else []


def merge_manifest(downloaded: Iterable[Episode], manifest_path: Path) -> None:
    existing = load_manifest_episodes(manifest_path)
    by_id = {str(item.get("id") or ""): item for item in existing if item.get("id")}
    ordered_ids = [str(item.get("id") or "") for item in existing if item.get("id")]

    for episode in downloaded:
        updated = datetime.now(timezone.utc).isoformat()
        item = {
            "id": episode.resource_id,
            "title": episode.title,
            "pubDate": episode.pub_date,
            "updated": updated,
            "pageUrl": episode.page_url,
            "description": episode.description,
            "author": episode.author,
            "imageUrl": episode.image_url,
            "originalUrl": episode.audio_url,
            "fileName": episode.file_name,
            "fileSize": episode.file_size,
            "mimeType": episode.mime_type,
        }
        if episode.resource_id not in by_id:
            ordered_ids.insert(0, episode.resource_id)
        by_id[episode.resource_id] = item

    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    merged = [by_id[item_id] for item_id in ordered_ids if item_id in by_id]
    manifest_path.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")


def manifest_ids(manifest_path: Path) -> set[str]:
    return {str(item.get("id")) for item in load_manifest_episodes(manifest_path) if item.get("id")}


def run_interactive(args: argparse.Namespace) -> None:
    client = XetClient(profile_dir=args.profile_dir, timeout=args.timeout)
    auth_state = client.ensure_logged_in(login_timeout=args.login_timeout)
    nickname = auth_state.get("data", {}).get("data", {}).get("nickname") or auth_state.get("data", {}).get("data", {}).get("b_user_id")
    if nickname:
        print(f"Logged in as: {nickname}")

    episodes = client.fetch_all_audio_episodes(page_size=args.page_size)
    if not episodes:
        print("No audio episodes found.")
        return

    selected = prompt_for_episodes(episodes)
    resolved = []
    for episode in selected:
        resolved.append(client.fetch_audio_info(episode))

    if args.resolve_only:
        print("")
        print("Resolved audio URLs:")
        for episode in resolved:
            print(f"- {episode.title}\n  {episode.audio_url}")
        write_csv(resolved, args.csv_output)
        print("")
        print(f"Wrote CSV to {args.csv_output.resolve()}")
        return

    downloaded = []
    for episode in resolved:
        print(f"Downloading: {episode.title}")
        downloaded.append(client.download_episode(episode, args.download_dir))

    write_csv(downloaded, args.csv_output)
    write_manifest(downloaded, args.manifest_output)

    print("")
    print(f"Downloaded {len(downloaded)} episode(s) to {args.download_dir.resolve()}")
    print(f"Wrote CSV to {args.csv_output.resolve()}")
    print(f"Wrote manifest to {args.manifest_output.resolve()}")


def run_latest(args: argparse.Namespace) -> None:
    client = XetClient(profile_dir=args.profile_dir, timeout=args.timeout)
    auth_state = client.ensure_logged_in(login_timeout=args.login_timeout)
    nickname = auth_state.get("data", {}).get("data", {}).get("nickname") or auth_state.get("data", {}).get("data", {}).get("b_user_id")
    if nickname:
        print(f"Logged in as: {nickname}")

    existing_ids = manifest_ids(args.manifest_output)
    candidates = client.fetch_all_audio_episodes(page_size=args.page_size)
    if args.max_scan:
        candidates = candidates[: args.max_scan]
    candidates = candidates[: args.limit]

    selected: list[Episode] = []
    for episode in candidates:
        if episode.resource_id in existing_ids:
            continue
        selected.append(episode)

    if not selected:
        print("No new episodes found.")
        return

    downloaded = []
    for episode in selected:
        resolved = client.fetch_audio_info(episode)
        print(f"Downloading: {resolved.title}")
        downloaded.append(client.download_episode(resolved, args.download_dir))

    write_csv(downloaded, args.csv_output)
    merge_manifest(downloaded, args.manifest_output)
    print("")
    print(f"Downloaded {len(downloaded)} new episode(s) to {args.download_dir.resolve()}")
    print(f"Updated manifest at {args.manifest_output.resolve()}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Xiaoetong audio downloader in Python.")

    subparsers = parser.add_subparsers(dest="command")

    interactive = subparsers.add_parser("interactive", help="Login, list episodes, choose and download.")
    interactive.add_argument("--profile-dir", type=Path, default=DEFAULT_PROFILE_DIR)
    interactive.add_argument("--download-dir", type=Path, default=DEFAULT_DOWNLOAD_DIR)
    interactive.add_argument("--csv-output", type=Path, default=DEFAULT_CSV_OUTPUT)
    interactive.add_argument("--manifest-output", type=Path, default=DEFAULT_MANIFEST_OUTPUT)
    interactive.add_argument("--page-size", type=int, default=DEFAULT_PAGE_SIZE)
    interactive.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    interactive.add_argument("--login-timeout", type=int, default=DEFAULT_LOGIN_TIMEOUT)
    interactive.add_argument("--resolve-only", action="store_true", help="Resolve and print audio_url without downloading files.")

    latest = subparsers.add_parser("latest", help="Download the newest episodes without prompting.")
    latest.add_argument("--profile-dir", type=Path, default=DEFAULT_PROFILE_DIR)
    latest.add_argument("--download-dir", type=Path, default=DEFAULT_DOWNLOAD_DIR)
    latest.add_argument("--csv-output", type=Path, default=DEFAULT_CSV_OUTPUT)
    latest.add_argument("--manifest-output", type=Path, default=DEFAULT_MANIFEST_OUTPUT)
    latest.add_argument("--page-size", type=int, default=DEFAULT_PAGE_SIZE)
    latest.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    latest.add_argument("--login-timeout", type=int, default=DEFAULT_LOGIN_TIMEOUT)
    latest.add_argument("--limit", type=int, default=1, help="Maximum new episodes to download.")
    latest.add_argument("--max-scan", type=int, default=64, help="Maximum recent episodes to inspect.")

    return parser


def main() -> int:
    parser = build_parser()
    argv = sys.argv[1:]
    parsed_argv = argv if argv[:1] == ["latest"] else ["interactive", *argv]
    args = parser.parse_args(parsed_argv)
    if args.command == "interactive":
        run_interactive(args)
        return 0
    if args.command == "latest":
        run_latest(args)
        return 0
    parser.error(f"Unknown command: {args.command}")
    return 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
