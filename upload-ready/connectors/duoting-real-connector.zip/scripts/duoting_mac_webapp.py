from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import mimetypes
import os
import re
import sys
import threading
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote

from flask import Flask, Response, jsonify, render_template, request, send_from_directory
from telethon import TelegramClient
from telethon.errors import PhoneCodeExpiredError, PhoneCodeInvalidError, SessionPasswordNeededError
from telethon.tl.types import DocumentAttributeAudio, DocumentAttributeFilename

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("DUOTING_DATA_DIR", str(BASE_DIR))).expanduser().resolve()
CONFIG_PATH = DATA_DIR / "app_config.json"
DOWNLOAD_ROOT = DATA_DIR / "downloads"
SESSION_DIR = DATA_DIR / "sessions"

DEFAULT_TARGET = "@duoting"
DEFAULT_SESSION = "duoting_user"
DEFAULT_PORT = int(os.getenv("DUOTING_APP_PORT", "9991"))
DOWNLOAD_RETRIES = max(1, int(os.getenv("DUOTING_DOWNLOAD_RETRIES", "3")))
SKIP_EXTERNAL_SUFFIXES = {
    str(item).strip()
    for item in json.loads(os.getenv("DUOTING_SKIP_EXTERNAL_SUFFIXES", "[]") or "[]")
    if str(item).strip()
}
SKIP_MESSAGE_IDS = {
    int(item)
    for item in json.loads(os.getenv("DUOTING_SKIP_MESSAGE_IDS", "[]") or "[]")
    if str(item).strip().isdigit()
}
WEB_USERNAME = os.getenv("DUOTING_WEB_USERNAME", "").strip()
WEB_PASSWORD = os.getenv("DUOTING_WEB_PASSWORD", "")
PODCAST_COVER_FILENAME = os.getenv("DUOTING_PODCAST_COVER_FILENAME", "podcast-cover.jpeg").strip()
MEDIA_TOKEN = (os.getenv("DUOTING_MEDIA_TOKEN", "") or os.getenv("DUOTING_FEED_TOKEN", "")).strip()
AUDIO_EXTENSIONS = {
    ".mp3",
    ".m4a",
    ".aac",
    ".wav",
    ".flac",
    ".ogg",
    ".oga",
    ".opus",
    ".wma",
    ".aiff",
    ".alac",
}

PENDING_LOGIN: dict[str, dict[str, str]] = {}
SYNC_LOCK = threading.Lock()
CLI_MODE = len(sys.argv) > 1 and sys.argv[1] in {"sync-once"}


@dataclass
class AppConfig:
    api_id: int | None = None
    api_hash: str = ""
    phone: str = ""
    target: str = DEFAULT_TARGET
    session_name: str = DEFAULT_SESSION

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AppConfig":
        api_id_value = data.get("api_id")
        api_id: int | None = None
        if api_id_value not in (None, ""):
            try:
                api_id = int(api_id_value)
            except (TypeError, ValueError):
                api_id = None

        target = normalize_target(str(data.get("target", DEFAULT_TARGET) or DEFAULT_TARGET))
        session_name = sanitize_filename(str(data.get("session_name", DEFAULT_SESSION) or DEFAULT_SESSION))
        if not session_name:
            session_name = DEFAULT_SESSION

        return cls(
            api_id=api_id,
            api_hash=str(data.get("api_hash", "") or "").strip(),
            phone=str(data.get("phone", "") or "").strip(),
            target=target,
            session_name=session_name,
        )

    def safe_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["api_hash_set"] = bool(self.api_hash)
        payload["api_hash"] = ""
        return payload


def ensure_dirs() -> None:
    DOWNLOAD_ROOT.mkdir(parents=True, exist_ok=True)
    SESSION_DIR.mkdir(parents=True, exist_ok=True)


def normalize_target(raw: str) -> str:
    value = (raw or "").strip()
    if not value:
        return DEFAULT_TARGET

    value = value.replace("https://web.telegram.org/k/#", "").replace("http://web.telegram.org/k/#", "")

    match = re.search(r"@[A-Za-z0-9_]+", value)
    if match:
        return match.group(0)

    if "t.me/" in value:
        tail = value.split("t.me/", 1)[1].strip().strip("/")
        tail = tail.split("?", 1)[0].split("/", 1)[0]
        if tail:
            return f"@{tail}"

    value = value.strip().strip("/")
    if value.startswith("@"):
        return value

    if re.fullmatch(r"[A-Za-z0-9_]+", value):
        return f"@{value}"

    return DEFAULT_TARGET


def sanitize_filename(name: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]", "_", name.strip())
    value = re.sub(r"_+", "_", value)
    return value.strip("._")[:180]


def load_config() -> AppConfig:
    if not CONFIG_PATH.exists():
        return AppConfig()

    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return AppConfig()

    return AppConfig.from_dict(data)


def save_config(new_data: dict[str, Any]) -> AppConfig:
    current = load_config()
    merged = asdict(current)

    for key in ["api_id", "api_hash", "phone", "target", "session_name"]:
        if key not in new_data:
            continue

        value = new_data.get(key)
        if key == "api_hash":
            text = str(value or "").strip()
            if text:
                merged[key] = text
        elif key in {"phone", "target", "session_name"}:
            merged[key] = str(value or "").strip()
        else:
            merged[key] = value

    cfg = AppConfig.from_dict(merged)
    CONFIG_PATH.write_text(json.dumps(asdict(cfg), ensure_ascii=False, indent=2), encoding="utf-8")
    return cfg


def require_core_credentials(cfg: AppConfig) -> None:
    if not cfg.api_id or not cfg.api_hash:
        raise ValueError("请先设置 api_id 和 api_hash。")


def target_folder_name(target: str) -> str:
    return sanitize_filename(target.replace("@", "").replace("/", "_")) or "duoting"


def target_download_dir(target: str) -> Path:
    path = DOWNLOAD_ROOT / target_folder_name(target)
    path.mkdir(parents=True, exist_ok=True)
    return path


def build_audio_relative_path(target: str, info: dict[str, Any]) -> str:
    message_id = int(info["message_id"])
    safe_name = sanitize_filename(info["file_name"]) or f"audio_{message_id}.mp3"
    return f"{target_folder_name(target)}/{message_id}_{safe_name}"


def should_skip_existing_download(target: str, info: dict[str, Any]) -> bool:
    message_id = int(info["message_id"])
    if message_id in SKIP_MESSAGE_IDS:
        return True
    rel = build_audio_relative_path(target, info)
    legacy_suffix = hashlib.md5(rel.encode("utf-8")).hexdigest()
    return legacy_suffix in SKIP_EXTERNAL_SUFFIXES


def session_path(session_name: str) -> Path:
    return SESSION_DIR / f"{session_name}.session"


def require_existing_session(cfg: AppConfig) -> Path:
    path = session_path(cfg.session_name)
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"未找到已有 Telegram session：{path}")
    return path


def find_audio_file(folder: Path, message_id: int) -> Path | None:
    return next(
        (
            item
            for item in folder.glob(f"{message_id}_*")
            if item.is_file() and item.suffix.lower() in AUDIO_EXTENSIONS
        ),
        None,
    )


def is_complete_audio_file(file_path: Path | None, expected_size: int = 0) -> bool:
    if file_path is None or not file_path.exists() or not file_path.is_file():
        return False

    actual_size = file_path.stat().st_size
    if expected_size > 0:
        return actual_size == expected_size
    return actual_size > 0


def is_file_downloaded(folder: Path, message_id: int, expected_size: int = 0) -> bool:
    return is_complete_audio_file(find_audio_file(folder, message_id), expected_size)


def resolve_download_path(relative_path: str) -> Path:
    candidate = (DOWNLOAD_ROOT / relative_path).resolve()
    try:
        candidate.relative_to(DOWNLOAD_ROOT.resolve())
    except ValueError as exc:
        raise ValueError("文件路径无效。") from exc
    return candidate


def atomic_write_text(path: Path, content: str) -> None:
    temp_path = Path(f"{path}.part")
    temp_path.write_text(content, encoding="utf-8")
    os.replace(temp_path, path)


def write_audio_sidecars(file_path: Path, info: dict[str, Any], target: str, caption: str) -> None:
    atomic_write_text(Path(f"{file_path}.txt"), caption)
    meta = {
        "message_id": info["message_id"],
        "target": target,
        "date": info["date"],
        "title": info["title"],
        "performer": info["performer"],
        "caption": caption,
        "duration": info["duration"],
        "size": info["size"],
        "saved_at": iso_time(datetime.now()),
    }
    atomic_write_text(Path(f"{file_path}.json"), json.dumps(meta, ensure_ascii=False, indent=2))


async def save_audio_message(
    client: TelegramClient,
    message: Any,
    info: dict[str, Any],
    target: str,
    out_dir: Path,
) -> dict[str, Any]:
    message_id = int(info["message_id"])
    rel = build_audio_relative_path(target, info)
    file_path = DOWNLOAD_ROOT / rel
    expected_size = int(info.get("size") or 0)

    if is_complete_audio_file(file_path, expected_size):
        status = "exists"
    else:
        temp_path = Path(f"{file_path}.part")
        last_error: Exception | None = None
        for attempt in range(1, DOWNLOAD_RETRIES + 1):
            temp_path.unlink(missing_ok=True)
            try:
                result = await client.download_media(message, file=str(temp_path))
                if result is None or not is_complete_audio_file(temp_path, expected_size):
                    actual_size = temp_path.stat().st_size if temp_path.exists() else 0
                    raise IOError(f"文件不完整（收到 {actual_size} 字节，预期 {expected_size} 字节）")
                os.replace(temp_path, file_path)
                status = "downloaded"
                break
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                temp_path.unlink(missing_ok=True)
                if attempt < DOWNLOAD_RETRIES:
                    await asyncio.sleep(min(attempt, 2))
        else:
            raise IOError(f"下载失败，已重试 {DOWNLOAD_RETRIES} 次：{last_error}") from last_error

    caption = (message.message or "").strip()
    write_audio_sidecars(file_path, info, target, caption)

    return {
        "message_id": message_id,
        "status": status,
        "file": rel,
        "url": f"/downloads/{quote(rel)}",
        "stream_url": f"/media/{quote(rel)}",
    }


async def get_login_state(cfg: AppConfig) -> dict[str, Any]:
    if not cfg.api_id or not cfg.api_hash:
        return {"configured": False, "authorized": False}

    try:
        path = require_existing_session(cfg)
    except FileNotFoundError:
        return {"configured": True, "authorized": False, "session_exists": False}

    client = TelegramClient(str(path), cfg.api_id, cfg.api_hash)
    try:
        await client.connect()
        return {"configured": True, "authorized": bool(await client.is_user_authorized()), "session_exists": True}
    finally:
        if client.is_connected():
            await client.disconnect()


def run_async(coro: Any) -> Any:
    return asyncio.run(coro)


def iso_time(value: datetime | None) -> str:
    if not value:
        return ""
    return value.strftime("%Y-%m-%d %H:%M:%S")


def extract_audio_info(message: Any) -> dict[str, Any] | None:
    if message is None:
        return None

    document = getattr(message, "document", None)
    if not document:
        return None

    audio_attr = None
    filename_attr = None
    for attr in document.attributes:
        if isinstance(attr, DocumentAttributeAudio):
            audio_attr = attr
        if isinstance(attr, DocumentAttributeFilename):
            filename_attr = attr

    if not audio_attr:
        return None

    caption = (message.message or "").strip()
    performer = (audio_attr.performer or "").strip()
    title = (audio_attr.title or "").strip()

    file_name = ""
    if filename_attr and filename_attr.file_name:
        file_name = filename_attr.file_name

    if not file_name:
        base = "_".join(x for x in [performer, title] if x)
        base = sanitize_filename(base) or f"audio_{message.id}"
        ext = mimetypes.guess_extension(document.mime_type or "") or ".mp3"
        file_name = f"{base}{ext}"

    return {
        "message_id": message.id,
        "date": iso_time(getattr(message, "date", None)),
        "file_name": file_name,
        "performer": performer,
        "title": title,
        "duration": int(audio_attr.duration or 0),
        "size": int(document.size or 0),
        "caption": caption,
    }


async def with_user_client(cfg: AppConfig, fn: Any) -> Any:
    require_core_credentials(cfg)

    path = require_existing_session(cfg)
    client = TelegramClient(str(path), cfg.api_id, cfg.api_hash)
    try:
        await client.connect()
        if not await client.is_user_authorized():
            raise PermissionError("已有 Telegram session 未授权或已失效；请在原 Web 管理端处理登录，不要由自动任务触发验证码。")

        return await fn(client)
    finally:
        if client.is_connected():
            await client.disconnect()


async def send_login_code(cfg: AppConfig) -> dict[str, Any]:
    require_core_credentials(cfg)
    if not cfg.phone:
        raise ValueError("请先填写手机号（phone）。")

    client = TelegramClient(str(session_path(cfg.session_name)), cfg.api_id, cfg.api_hash)
    try:
        await client.connect()
        if await client.is_user_authorized():
            return {"authorized": True, "sent": False}

        sent = await client.send_code_request(cfg.phone)
        PENDING_LOGIN[cfg.session_name] = {
            "phone": cfg.phone,
            "phone_code_hash": sent.phone_code_hash,
        }
        return {"authorized": False, "sent": True}
    finally:
        if client.is_connected():
            await client.disconnect()


async def verify_login_code(cfg: AppConfig, code: str) -> dict[str, Any]:
    require_core_credentials(cfg)
    state = PENDING_LOGIN.get(cfg.session_name)
    if not state:
        raise ValueError("请先发送验证码。")

    client = TelegramClient(str(session_path(cfg.session_name)), cfg.api_id, cfg.api_hash)
    try:
        await client.connect()
        await client.sign_in(phone=state["phone"], code=code, phone_code_hash=state["phone_code_hash"])
        PENDING_LOGIN.pop(cfg.session_name, None)
        return {"authorized": True, "need_password": False}
    except SessionPasswordNeededError:
        return {"authorized": False, "need_password": True}
    except (PhoneCodeInvalidError, PhoneCodeExpiredError) as exc:
        raise ValueError(f"验证码无效：{exc}") from exc
    finally:
        if client.is_connected():
            await client.disconnect()


async def verify_password(cfg: AppConfig, password: str) -> dict[str, Any]:
    require_core_credentials(cfg)

    client = TelegramClient(str(session_path(cfg.session_name)), cfg.api_id, cfg.api_hash)
    try:
        await client.connect()
        await client.sign_in(password=password)
        PENDING_LOGIN.pop(cfg.session_name, None)
        return {"authorized": True}
    finally:
        if client.is_connected():
            await client.disconnect()


async def refresh_audio_list(cfg: AppConfig, limit: int) -> dict[str, Any]:
    target = normalize_target(cfg.target)

    async def _work(client: TelegramClient) -> dict[str, Any]:
        entity = await client.get_entity(target)
        rows: list[dict[str, Any]] = []
        folder = target_download_dir(target)
        auto_downloaded = 0

        async for message in client.iter_messages(entity, limit=limit):
            info = extract_audio_info(message)
            if not info:
                continue

            info["downloaded"] = is_file_downloaded(folder, message.id, info["size"])
            rows.append(info)

        return {"target": target, "count": len(rows), "items": rows, "auto_downloaded": auto_downloaded}

    return await with_user_client(cfg, _work)


async def sync_audio_list(cfg: AppConfig, limit: int, auto_download: bool) -> dict[str, Any]:
    target = normalize_target(cfg.target)

    async def _work(client: TelegramClient) -> dict[str, Any]:
        entity = await client.get_entity(target)
        rows: list[dict[str, Any]] = []
        folder = target_download_dir(target)
        auto_downloaded = 0

        async for message in client.iter_messages(entity, limit=limit):
            info = extract_audio_info(message)
            if not info:
                continue

            if should_skip_existing_download(target, info):
                info["downloaded"] = True
                info["skipped_existing"] = True
                rows.append(info)
                continue

            downloaded = is_file_downloaded(folder, message.id, info["size"])
            if auto_download and not downloaded:
                result = await save_audio_message(client, message, info, target, folder)
                downloaded = result["status"] in {"downloaded", "exists"}
                if result["status"] == "downloaded":
                    auto_downloaded += 1

            info["downloaded"] = downloaded
            rows.append(info)

        return {"target": target, "count": len(rows), "items": rows, "auto_downloaded": auto_downloaded}

    return await with_user_client(cfg, _work)


async def download_audio(cfg: AppConfig, message_ids: list[int]) -> dict[str, Any]:
    target = normalize_target(cfg.target)

    async def _work(client: TelegramClient) -> dict[str, Any]:
        entity = await client.get_entity(target)
        out_dir = target_download_dir(target)
        results: list[dict[str, Any]] = []

        for message_id in message_ids:
            message = await client.get_messages(entity, ids=message_id)
            info = extract_audio_info(message)

            if not info:
                results.append(
                    {
                        "message_id": message_id,
                        "status": "skipped",
                        "reason": "该消息不是音频。",
                    }
                )
                continue

            results.append(await save_audio_message(client, message, info, target, out_dir))

        return {"target": target, "results": results}

    return await with_user_client(cfg, _work)


def list_downloaded_files() -> list[dict[str, Any]]:
    files: list[dict[str, Any]] = []
    if not DOWNLOAD_ROOT.exists():
        return files

    for file_path in sorted(DOWNLOAD_ROOT.rglob("*"), reverse=True):
        if not file_path.is_file() or file_path.suffix.lower() not in AUDIO_EXTENSIONS:
            continue

        rel = file_path.relative_to(DOWNLOAD_ROOT).as_posix()
        txt_path = Path(f"{file_path}.txt")
        meta_path = Path(f"{file_path}.json")
        caption = txt_path.read_text(encoding="utf-8").strip() if txt_path.exists() else ""
        metadata: dict[str, Any] = {}
        expected_size = 0
        if meta_path.exists():
            try:
                metadata = json.loads(meta_path.read_text(encoding="utf-8"))
                expected_size = int(metadata.get("size") or 0)
            except (json.JSONDecodeError, TypeError, ValueError):
                metadata = {}
                expected_size = 0

        files.append(
            {
                "message_id": metadata.get("message_id"),
                "file": rel,
                "url": f"/downloads/{quote(rel)}",
                "stream_url": f"/media/{quote(rel)}",
                "size": file_path.stat().st_size,
                "expected_size": expected_size,
                "complete": is_complete_audio_file(file_path, expected_size),
                "date": metadata.get("date", ""),
                "title": metadata.get("title", ""),
                "performer": metadata.get("performer", ""),
                "duration": int(metadata.get("duration") or 0),
                "caption": caption,
                "updated": iso_time(datetime.fromtimestamp(file_path.stat().st_mtime)),
            }
        )

    return files


def media_path_is_public(path: str) -> bool:
    return bool(MEDIA_TOKEN) and path.startswith(f"/episode/{MEDIA_TOKEN}/")


def run_locked_sync(cfg: AppConfig, limit: int, auto_download: bool) -> dict[str, Any]:
    if not SYNC_LOCK.acquire(blocking=False):
        raise RuntimeError("已有同步任务正在运行，请稍后再试。")
    try:
        return run_async(sync_audio_list(cfg, limit, auto_download))
    finally:
        SYNC_LOCK.release()


def run_download_once(limit: int) -> dict[str, Any]:
    if not SYNC_LOCK.acquire(blocking=False):
        raise RuntimeError("已有同步任务正在运行，请稍后再试。")
    try:
        return run_async(sync_audio_list(load_config(), limit, True))
    finally:
        SYNC_LOCK.release()


def delete_downloaded_file(relative_path: str) -> dict[str, Any]:
    file_path = resolve_download_path(relative_path)
    if not file_path.exists() or not file_path.is_file():
        raise FileNotFoundError("文件不存在。")

    removed: list[str] = []
    for target in [file_path, Path(f"{file_path}.txt"), Path(f"{file_path}.json")]:
        if target.exists() and target.is_file():
            target.unlink()
            removed.append(target.relative_to(DOWNLOAD_ROOT).as_posix())

    return {"file": relative_path, "removed": removed}


def make_error(message: str, status_code: int = 400):
    return jsonify({"ok": False, "error": message}), status_code


def parse_limit(raw: Any, default: int = 120) -> int:
    try:
        value = int(raw)
    except (TypeError, ValueError):
        value = default
    return max(1, min(value, 500))


ensure_dirs()
app = Flask(__name__, template_folder=str(BASE_DIR / "templates"))


@app.before_request
def require_site_auth():
    if (
        not WEB_PASSWORD
        or request.path == "/health"
        or request.path == f"/static/{PODCAST_COVER_FILENAME}"
        or media_path_is_public(request.path)
    ):
        return None

    auth = request.authorization
    username_ok = auth is not None and hmac.compare_digest(auth.username or "", WEB_USERNAME)
    password_ok = auth is not None and hmac.compare_digest(auth.password or "", WEB_PASSWORD)
    if username_ok and password_ok:
        return None

    return Response("Authentication required.", 401, {"WWW-Authenticate": 'Basic realm="Duoting"'})


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/health")
def health():
    return jsonify({"ok": True})


@app.route("/api/config", methods=["GET"])
def get_config():
    return jsonify({"ok": True, "config": load_config().safe_dict()})


@app.route("/api/config", methods=["POST"])
def update_config():
    payload = request.get_json(silent=True) or {}
    cfg = save_config(payload)
    return jsonify({"ok": True, "config": cfg.safe_dict()})


@app.route("/api/state", methods=["GET"])
def api_state():
    cfg = load_config()
    limit = parse_limit(request.args.get("limit", 120))
    auto_download = str(request.args.get("auto_download", "0")).strip().lower() not in {"0", "false", "no"}

    try:
        login_state = run_async(get_login_state(cfg))
        response: dict[str, Any] = {"ok": True, "config": cfg.safe_dict(), **login_state}
        if login_state["authorized"]:
            response.update(run_locked_sync(cfg, limit, auto_download))
        response["files"] = list_downloaded_files()
        return jsonify(response)
    except Exception as exc:  # noqa: BLE001
        return make_error(str(exc))


@app.route("/api/auth/send_code", methods=["POST"])
def api_send_code():
    cfg = load_config()
    try:
        data = run_async(send_login_code(cfg))
        return jsonify({"ok": True, **data})
    except Exception as exc:  # noqa: BLE001
        return make_error(str(exc))


@app.route("/api/auth/verify_code", methods=["POST"])
def api_verify_code():
    cfg = load_config()
    payload = request.get_json(silent=True) or {}
    code = str(payload.get("code", "")).strip()
    if not code:
        return make_error("请输入验证码。")

    try:
        data = run_async(verify_login_code(cfg, code))
        return jsonify({"ok": True, **data})
    except Exception as exc:  # noqa: BLE001
        return make_error(str(exc))


@app.route("/api/auth/verify_password", methods=["POST"])
def api_verify_password():
    cfg = load_config()
    payload = request.get_json(silent=True) or {}
    password = str(payload.get("password", "")).strip()
    if not password:
        return make_error("请输入二步验证密码。")

    try:
        data = run_async(verify_password(cfg, password))
        return jsonify({"ok": True, **data})
    except Exception as exc:  # noqa: BLE001
        return make_error(str(exc))


@app.route("/api/refresh", methods=["POST"])
def api_refresh():
    cfg = load_config()
    payload = request.get_json(silent=True) or {}
    limit = parse_limit(payload.get("limit", 120))
    auto_download = bool(payload.get("auto_download", False))

    try:
        data = run_locked_sync(cfg, limit, auto_download)
        return jsonify({"ok": True, **data})
    except Exception as exc:  # noqa: BLE001
        return make_error(str(exc))


@app.route("/api/list_audio", methods=["GET", "POST"])
def api_list_audio():
    cfg = load_config()
    if request.method == "POST":
        payload = request.get_json(silent=True) or {}
        limit = parse_limit(payload.get("limit", 120))
        auto_download = bool(payload.get("auto_download", False))
    else:
        limit = parse_limit(request.args.get("limit", 120))
        auto_download = str(request.args.get("auto_download", "0")).strip().lower() not in {"0", "false", "no"}

    try:
        data = run_locked_sync(cfg, limit, auto_download)
        return jsonify({"ok": True, **data})
    except Exception as exc:  # noqa: BLE001
        return make_error(str(exc))


@app.route("/api/download", methods=["POST"])
def api_download():
    cfg = load_config()
    payload = request.get_json(silent=True) or {}
    raw_ids = payload.get("message_ids", [])
    if not isinstance(raw_ids, list):
        return make_error("message_ids 必须是数组。")

    ids: list[int] = []
    for raw in raw_ids:
        try:
            ids.append(int(raw))
        except (TypeError, ValueError):
            continue

    if not ids:
        return make_error("请选择至少一个音频。")

    try:
        if not SYNC_LOCK.acquire(blocking=False):
            raise RuntimeError("已有同步任务正在运行，请稍后再试。")
        try:
            data = run_async(download_audio(cfg, ids))
        finally:
            SYNC_LOCK.release()
        return jsonify({"ok": True, **data})
    except Exception as exc:  # noqa: BLE001
        return make_error(str(exc))


@app.route("/api/list_downloaded", methods=["GET"])
def api_list_downloaded():
    return jsonify({"ok": True, "files": list_downloaded_files()})


@app.route("/api/delete_downloaded", methods=["POST"])
def api_delete_downloaded():
    payload = request.get_json(silent=True) or {}
    relative_path = str(payload.get("file", "")).strip()
    if not relative_path:
        return make_error("请指定要删除的文件。")

    try:
        deleted = delete_downloaded_file(relative_path)
        return jsonify({"ok": True, **deleted, "files": list_downloaded_files()})
    except Exception as exc:  # noqa: BLE001
        return make_error(str(exc))


@app.route("/media/<path:relative_path>", methods=["GET"])
def serve_media(relative_path: str):
    resolved = resolve_download_path(relative_path)
    return send_from_directory(str(resolved.parent), resolved.name, as_attachment=False)


@app.route("/downloads/<path:relative_path>", methods=["GET"])
def serve_download(relative_path: str):
    return send_from_directory(str(DOWNLOAD_ROOT), relative_path, as_attachment=True)


@app.route("/podcast/<path:relative_path>", methods=["GET"])
def serve_podcast_media(relative_path: str):
    resolved = resolve_download_path(relative_path)
    return send_from_directory(str(resolved.parent), resolved.name, as_attachment=False)


@app.route("/episode/<token>/<path:relative_path>", methods=["GET"])
def serve_episode_media(token: str, relative_path: str):
    if not MEDIA_TOKEN or not hmac.compare_digest(token, MEDIA_TOKEN):
        return Response("Not found.", 404)
    resolved = resolve_download_path(relative_path)
    return send_from_directory(str(resolved.parent), resolved.name, as_attachment=False)


if __name__ == "__main__":
    if CLI_MODE:
        raw_limit = sys.argv[sys.argv.index("--limit") + 1] if "--limit" in sys.argv and sys.argv.index("--limit") + 1 < len(sys.argv) else 120
        print(json.dumps(run_download_once(parse_limit(raw_limit)), ensure_ascii=False, indent=2))
    else:
        app.run(host="0.0.0.0", port=DEFAULT_PORT, debug=False)
