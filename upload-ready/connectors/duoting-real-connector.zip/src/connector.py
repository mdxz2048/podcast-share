import hashlib
import json
import os
import shutil
import subprocess
import sys
import base64
from datetime import datetime, timezone
from pathlib import Path


def emit(event):
    print(json.dumps(event, ensure_ascii=False), flush=True)


def iso_now():
    return datetime.now(timezone.utc).isoformat()


def parse_json_env(name, default):
    raw = os.getenv(name, "")
    if not raw:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default


def scan_media_files(media_root: Path):
    exts = {".mp3", ".m4a", ".aac", ".ogg", ".wav", ".flac", ".oga", ".opus"}
    files = []
    for file in media_root.rglob("*"):
        if file.is_file() and file.suffix.lower() in exts:
            files.append(file)
    files.sort()
    return files


def file_checksum(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def content_type(path: Path):
    mapping = {
        ".mp3": "audio/mpeg",
        ".m4a": "audio/mp4",
        ".aac": "audio/aac",
        ".ogg": "audio/ogg",
        ".wav": "audio/wav",
        ".flac": "audio/flac",
        ".oga": "audio/ogg",
        ".opus": "audio/ogg",
    }
    return mapping.get(path.suffix.lower(), "audio/mpeg")


def existing_duoting_suffixes(source_name: str, external_ids):
    if not isinstance(external_ids, list):
        return []
    prefix = f"duoting:{source_name}:"
    values = []
    seen = set()
    for raw in external_ids:
        if not isinstance(raw, str) or not raw.startswith(prefix):
            continue
        suffix = raw[len(prefix):].strip()
        if not suffix or suffix in seen:
            continue
        seen.add(suffix)
        values.append(suffix)
    return values


def existing_duoting_message_ids(source_name: str, external_ids):
    ids = []
    for suffix in existing_duoting_suffixes(source_name, external_ids):
        if suffix.isdigit():
            ids.append(int(suffix))
    return ids


if __name__ == "__main__":
    input_json = parse_json_env("CONNECTOR_INPUT_JSON", {})
    output_root = Path(os.getenv("CONNECTOR_OUTPUT_ROOT", "/work/output"))
    media_root = output_root / "media"
    media_root.mkdir(parents=True, exist_ok=True)

    source_name = str(input_json.get("source_name", "duoting-real"))
    program_title = str(input_json.get("program_title", "Duoting 真实导入"))
    limit = int(input_json.get("limit", 30) or 30)

    connector_root = Path.cwd()
    script_abs = connector_root / "scripts/duoting_mac_webapp.py"
    runtime_data = connector_root / "runtime_data"

    # Ensure downloaded audio lands under CONNECTOR_OUTPUT_ROOT/media
    work_data = output_root / "duoting-runtime"
    if work_data.exists():
        shutil.rmtree(work_data)
    shutil.copytree(runtime_data, work_data)
    os.makedirs(work_data / "downloads", exist_ok=True)
    os.makedirs(work_data / "sessions", exist_ok=True)

    auth_payload = work_data / "auth/duoting_auth_payload.txt"
    if auth_payload.exists():
        raw = auth_payload.read_text(encoding="utf-8").strip()
        (work_data / "sessions/duoting_user.session").write_bytes(base64.b64decode(raw))

    cmd = [sys.executable, str(script_abs), "sync-once", "--limit", str(max(1, limit))]
    env = os.environ.copy()
    env["DUOTING_DATA_DIR"] = str(work_data)
    env["DUOTING_SKIP_EXTERNAL_SUFFIXES"] = json.dumps(
        existing_duoting_suffixes(source_name, input_json.get("existing_external_episode_ids")),
        ensure_ascii=False,
    )
    env["DUOTING_SKIP_MESSAGE_IDS"] = json.dumps(
        existing_duoting_message_ids(source_name, input_json.get("existing_external_episode_ids")),
        ensure_ascii=False,
    )

    result = subprocess.run(cmd, cwd=str(connector_root), env=env, capture_output=True, text=True)
    if result.stdout.strip():
        emit({"type": "log", "level": "info", "message": result.stdout.strip()[:4000]})
    if result.stderr.strip():
        emit({"type": "log", "level": "warn", "message": result.stderr.strip()[:4000]})

    if result.returncode != 0:
        emit({"type": "log", "level": "error", "message": f"duoting script exit code={result.returncode}"})
        raise SystemExit(result.returncode)

    # Duoting downloads to DUOTING_DATA_DIR/downloads/**, copy audio files to media_root first.
    duoting_downloads = work_data / "downloads"
    for file in scan_media_files(duoting_downloads):
        rel = file.relative_to(duoting_downloads).as_posix()
        target = media_root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file, target)

    external_program_id = f"duoting:{source_name}"
    emit(
        {
            "type": "program",
            "external_program_id": external_program_id,
            "title": program_title,
            "description": f"Imported by real duoting script source={source_name}",
        }
    )

    for file in scan_media_files(media_root):
        rel = file.relative_to(media_root).as_posix()
        eid = f"duoting:{source_name}:{hashlib.md5(rel.encode('utf-8')).hexdigest()}"
        emit(
            {
                "type": "episode",
                "external_episode_id": eid,
                "program_external_id": external_program_id,
                "title": file.stem,
                "description": "Imported from real duoting script",
                "published_at": iso_now(),
            }
        )
        emit(
            {
                "type": "media_ready",
                "external_episode_id": eid,
                "file": f"media/{rel}",
                "content_type": content_type(file),
                "size": file.stat().st_size,
                "checksum": file_checksum(file),
            }
        )
