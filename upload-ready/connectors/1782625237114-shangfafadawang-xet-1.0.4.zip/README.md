# 发发大王播客 Connector

基于小鹅通 xet.py 脚本封装的发发大王播客专属导入器。

- 每半天运行一次
- 自动下载新集
- 自动从 study 登录态刷新 H5 `ko_token`
- 通过 Source secret 持久化刷新后的 cookie jar

注意：study 侧 cookie 和 H5 侧 `ko_token` 是两套登录态。脚本会用学习列表里的店铺
`user_id` 调用小鹅通 `kotoken.create`，生成新的 H5 `ko_token`，并通过 `auth_update`
写回 Source secret，供后续定时任务继续使用。
